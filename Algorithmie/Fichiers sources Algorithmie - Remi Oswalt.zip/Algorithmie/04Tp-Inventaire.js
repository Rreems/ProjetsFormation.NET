// **** Création d'object JS :o !!
    // class Inv {
    // constructor(nom, qte, prix) {
    //     this.nom = nom;
    //     this.qte = qte;
    //     this.prix = prix;
    //     }
    // }   
    //   let thisInv = new Inv("Boule", 40, 2);
    //   console.log(thisInv);


// ***********************************************************
// ***  Format & initialisation Inventaire

let inventaire = [
    new Map([
        [ "nom", "Boules de Noël" ],
        [ "quantite", 50 ],
        [ "prix", 1.5 ]  ])
        ,
    new Map([
        [ "nom", "Guirlandes" ],
        [ "quantite", 30 ],
        [ "prix", 3.0 ]  ])        
        ,
    new Map([
        [ "nom", "Sapin de Noël" ],
        [ "quantite", 10 ],
        [ "prix", 25.0 ]  ])          

        ,
    new Map([
        [ "nom", "r" ],
        [ "quantite", 200 ],
        [ "prix", 1 ]  ])            

    ] ;

      
    

// ***********************************************************
// ***  Tests accès DOM 
// RANGER LE DOM BORDEL:
    // // On met en page l'affichage
    // firstDiv.innerHTML = `
    //     <div>
    //         <h1>${contenuTitre}</h1>
    //         <p>${contenuParagraphe}</p>
    //         <p>${stringResult}</p>
    //     </div>



// Création d'un div avec createElement. Dans cette div, on va créer un titre h1 et un paragraphe p
let firstDiv = document.createElement("firstDiv")

let contenuTitre = "<img src=\"Inventaire-King-Jouet.gif\" alt=\"Superbe image\" />"
let contenuParagraphe = "L'application est en projet tkt"

let body = document.querySelector("body") ;


    firstDiv.innerHTML = `
        <div>
            <h1>${contenuTitre}</h1>
            <p>${contenuParagraphe}</p>
        </div>`
    body.appendChild(firstDiv);        
    
        
    let divParamFct = document.createElement("divParamFct");
//divParamFct.innerHTML= "rien de spécial.";


let paragLstInv = document.createElement("paragLstInv");
paragLstInv.innerHTML= "<p>Liste vide</P>";

//*************************************** */
//    Contenu - boutons
//*************************************** */


// ****************
// Bouton Afficher liste
let divBoutonAfficher = document.createElement("divBoutonAfficher");

// divBoutonAfficher.innerHTML= `
// <button id="boutonAfficher">Afficher inventaire</button> `  ;

divBoutonAfficher.innerHTML= `
    <img src=\"Afficher.gif\" alt=\"Superbe image\" max-width=\"80\" height=\"80\"/>`;

body.appendChild(divBoutonAfficher);


divBoutonAfficher.addEventListener("click", function(){
    paragLstInv.innerHTML=
            fctButtonPressedAfficher();

                    
});

// ****************
// Bouton Ajouter
let divBoutonAdd = document.createElement("divBoutonAdd")

// divBoutonAdd.innerHTML= `
// <button id="boutonAdd">Ajout à l'inventaire</button> `  ;
divBoutonAdd.innerHTML= `
    <img src=\"Ajouter.gif\" alt=\"Superbe image\"  max-width=\"80\" height=\"80\"/>
` ;

body.appendChild(divBoutonAdd);

divBoutonAdd.addEventListener("click", function(){
    
    fctButtonPressedAdd();

    paragLstInv.innerHTML= "<br> Element ajouté !<br>" + fctButtonPressedAfficher();

});

// ****************
// Bouton Search
let divBoutonSearch = document.createElement("divBoutonSearch")

// divBoutonSearch.innerHTML= `
// <button id="boutonSearch">Rechercher inventaire</button> `  ;
divBoutonSearch.innerHTML= `
    <img src=\"Rechercher.gif\" alt=\"Superbe image\"  max-width=\"100\" height=\"100\"/>
` ;

body.appendChild(divBoutonSearch);

divBoutonSearch.addEventListener("click", function(){


    
    // let baliseChamp1 = document.getElementById("champ1")
    // let valueChamp1 = baliseChamp1.value



    paragLstInv.innerHTML=
            fctButtonPressedSearch("rechercher")[0];


});

// ****************
// Bouton QUITTER
let divBoutonQuit = document.createElement("divBoutonQuit")

// divBoutonQuit.innerHTML= `
// <button id="boutonQuit">Tout abandonner (；′⌒\`)</button> `  ;
divBoutonQuit.innerHTML= `
    <img src=\"Quit.gif\" alt=\"Superbe image\"  max-width=\"100\" height=\"100\"/>
` ;

body.appendChild(divBoutonQuit);

divBoutonQuit.addEventListener("click", function(){

    window.close();
});


// *******************************************
// **** SUITE ACCES AU DOM
body.appendChild(paragLstInv);

body.appendChild(divParamFct);


// //   Tracker d'appui touche
// document.addEventListener('keydown', (event) => {
//     console.log("key: " + event.key + "\ntarget: " + event.target + "\n" + "x:"+ event.clientX +" y:"+ event.clientY );
// });



// ***********************************************************
// ***  fonction bouton  AFFICHER

// **************************************************
// **
function fctButtonPressedAfficher(varEntr) {
    let resultRetour = "" ;
    //alert("Appel Fct Afficher");
    console.log("Appel Fct Afficher");
    
    resultRetour= `<p>Fct afficher <br>Liste: </p>` ;
    
    for (let i = 0; i < inventaire.length; i++) {
        inventaire[i].forEach((values, keys) => {
            
            resultRetour+= "<br>- " + keys + " :  " + values ;
            // console.log(values, keys)
            
        })
        resultRetour+="<br>"
    };  
    resultRetour+= "</p>" ;
    
    return resultRetour;
}


// ***********************************************************
// ***  fonction trouver Item
// **************************************************
// **
function fctFindItem(varEntr) {
    let resultRetour = "" ;
    let elemRech = varEntr ;
    let elemTrouveBool = false;    


    for (let i = 0; i < inventaire.length; i++) {
        inventaire[i].forEach((values, keys) => {

            // resultRetour+= "<br>- " + keys + " :  " + values ;
            // console.log(values, keys)
            if (values == elemRech && keys == "nom") {                    
                elemTrouveBool = true;
                indiceTrv = i ;
            }

        })

    };


    return [elemTrouveBool , indiceTrv];
};  


// ***********************************************************
// ***  fonction bouton  RECHERCHER / SEARCH
// **************************************************
// **
function fctButtonPressedSearch(varEntr) {
    let resultRetour = "" ;
    //alert("Appel Fct Search");
    console.log("Appel Fct Search");
    
    resultRetour= `<p>Fct Recherche </p>` ;

    let elemRech = prompt("Quel article est à " + varEntr + " ? ");
    let elemTrouveBool = false;

    let indiceTrv = -1 ;

    for (let i = 0; i < inventaire.length; i++) {
        inventaire[i].forEach((values, keys) => {

            // resultRetour+= "<br>- " + keys + " :  " + values ;
            // console.log(values, keys)
            if (values == elemRech && keys == "nom") {
                resultRetour+= "Element trouvé: <br>- nom : " + values ;
                resultRetour+= `<br>- quantité :  ${inventaire[i].get("quantite")} 
                                <br>- prix : ${inventaire[i].get("prix")} ` ;
                    
                elemTrouveBool = true;
                indiceTrv = i ;
            }

        })
        resultRetour+="<br>"
    };  

    if ( ! elemTrouveBool) {
        resultRetour+=`Element non trouvé  :/ `
    }

    console.log("elem trouvé ? " + elemTrouveBool + "\n Indice: " + indiceTrv );

    return [resultRetour, elemTrouveBool , indiceTrv, elemRech];
};


// ***********************************************************
// ***  fonction bouton  AJOUT / ADD
// **************************************************
// **
function fctButtonPressedAdd(varEntr) {
    console.log("Appel Fct Ajout");

    let nomRech = prompt ("Quel est le nom de l'article à ajouter ?")

    let resultRech = fctFindItem(nomRech) ;   // return [elemTrouveBool , indiceTrv];
    console.log("Result Rech: " + resultRech);

    if (resultRech[0]) {
        // Trouvé: ajout aux existants 
        let nbItemActuel = inventaire[resultRech[1]].get("quantite") ;
        console.log("nbItemActuel:" + nbItemActuel);      

        let nbToAdd = Number(prompt ("Article déjà en table. Combien en ajouter ?"));
        
        inventaire[resultRech[1]].set("quantite" , nbItemActuel + nbToAdd);
        console.log("Nb après modif: " + inventaire[resultRech[1]].get("quantite"));      


    } else {
        let nomToAdd = nomRech ;
        let qttToAdd = Number(prompt ("Nouvel article. Quelle quantité en ajouter ?"));
        let prixToAdd = Number(prompt ("Quel prix lui fixer ?"));

        inventaire.push(
            new Map([
                [ "nom", nomToAdd ],
                [ "quantite", qttToAdd ],
                [ "prix", prixToAdd ]  ])           

        );
        
    }
};