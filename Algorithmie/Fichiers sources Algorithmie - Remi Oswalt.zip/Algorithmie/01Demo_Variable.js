

let maVar1 = 3.14 ;

let maVar2 = 'É' ;

let maVar3 = 0 ;

let varSomme = maVar1 + maVar2 ;

let char1 = 'z'

let string1 = "4gge" ;

let booleen =  false ;

console.log("Salut le monde.");

////////////////////////Echange var /////////////////////
console.log("Valeur 1 avant :" + maVar1 
            + "\nValeur 2 avant:" + maVar2 );
maVar3 = maVar1 ;
maVar1 = maVar2 ;
maVar2 = maVar3 ;
console.log("Valeur 1 après :" , maVar1 
            + "\nValeur 2 après:" , maVar2 );            
/////////////////////////////////////////////////////////

